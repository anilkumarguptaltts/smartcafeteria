===========================================Information :==============================================
npm install (command used for both frontend & backend, download library.)
===========================================Configuration :==============================================
Version : angular 11
Nodejs  : v12.16.1
Npm     : 6.13.4
MongoDB server version: 4.0.18
===========================================Front end :==============================================
Step :-1 ng new task (create project)
Step :-2 Create 3 modules
ng generate module login --route login --module app.module (for login)
ng generate module signup --route signup --module app.module (for signup)
ng generate module menulist --route menulist --module app.module (for show list)
ng generate module addmenu --route addmenu --module app.module (for show list)
ng generate module user-details --route user-details --module app.module (show data)
ng generate module homepage --route homepage --module app.module (show data)

Step :-3 Create common Service for transfer data between frontend to backend
Step :-4 Create token Service check in login time.
Step :-5 Create auth Service for login and registration.
Step :-6 use JWT for generate token, check user login or not.
Step :-7 used gurds for , without login user can not access the page.
Step :-8 set all routing in app-routing.module.ts
Step :-9 import form module in, every componnt modules.
Step : 10 create folder for image uoload
Step : 11 create seperate files for validations
Step : 12 add validation server & client side both.
Step : 13 set routes for every componet.
===========================================Backend :============================================== 
Step-3: create form and add validation front end & backrnd.

Step-4: Install mongoose library for database connection.

=>Mongoose is an Object Data Modeling (ODM) library for MongoDB and Node.js. It manages relationships between data, provides schema validation, and is used to translate between objects in code and the representation of those objects in MongoDB.


Step-5: Install sweetalert2 library for alert message.
Step-6: Install body-parser 

=>Body-parser allows express to read the body and then parse that into a JSON object that we can understand.

Step-7: npm init.

Step-8: npm install --save express. 
=>Express is a module framework for Node that you can use for applications.

Step-9: npm i bcryptjs.
=>this is install for password hashing.

Step-10: 
npm install passport passport-local --save
npm install passport-local-mongoose --save
=>Express.js uses a cookie to store a session id

Step-11: 
npm install rootpath
=>Express.js uses a cookie to store a session id
