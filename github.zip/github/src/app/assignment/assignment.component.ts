import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { NgForm, FormGroup } from '@angular/forms';
import { CommonService } from 'src/app/global/services/common/common.service';
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {
  baseURL = environment.imageBaseUrl;

  @ViewChild('assignmentForm') form: FormGroup;
  title: string = 'Login Page';
  assignmentForm: boolean = false;
  fileData1:File;
  fileData1Label: string;
  fileData1Error:boolean = false;
  sessionData:any;
  image: any;
  getWeekList: any;
  getMenuListData:any;
  getMenuListData2:any;
  Week1:{};
  Week2:any;
  Week3:any;
  Week4:any;
  del:any;
  value: number = 0;
  isLoading: boolean = false;
  
  constructor(private router: Router,private common:CommonService) { }

  ngOnInit(): void {
    this.value = 90;
    this.getMenuList();

  }
  getMenuList(){
    this.common.getMenuListing().subscribe( response => {
   
    console.log(response.responseData);
    console.log("-------------123456-->");
    //return false;
      // var week = new Array(        
      //   "Monday",
      //   "Tuesday",
      //   "Wednesday",
      //   "Thursday",
      //   "Friday",
      //   "Saturday",
      //   "Sunday"
      // );
      this.getMenuListData = response.responseData;
      //this.getMenuListData2 = response.responseData;       
      },
      (error:any) => this.handleError(error)
    );
  }
  onFileSelect(event:any) {
    this.fileData1 = event.target.files[0];
    this.fileData1Label = this.fileData1.name;
    this.fileData1Error = false;
  }
  uploadExcel() {
    this.isLoading = true;
    this.assignmentForm = true;
    let data = {
      image: this.fileData1
    }
    
   

    //if (this.form.valid) {
      // console.log(data);
      // console.log("-------------123-->");
      // return false;
      this.common.uploadExcel(data).subscribe(response => {
        this.isLoading = false;
        
        this.handleResponse(response)
        },
        (error) => this.handleError(error)
      );
    // } else {
    // }
  }
  handleResponse(response:any) {   
    this.assignmentForm=false; 
    
   // console.log('========>>>>>>');
   // console.log(response);
   // console.log('<<<<<<<========');
    // return false;

    if(response.responseStatus==1){
      window.setTimeout(function()
      {
        location.reload();
      },1000)
      Swal.fire('Uploaded Successful!',response.responseMsgCode,'success');
      //this.router.navigate(['/assignment']);
    }
    else if(response.responseStatus==2){
     // window.location.reload();
      Swal.fire('Existing records already update and new records insert successfully!.',response.responseMsgCode,'success');
      //this.router.navigate(['/assignment']);
    }else if(response.responseStatus==3){
      //window.location.reload();
      Swal.fire('Please choose file.',response.responseMsgCode,'error');
      //this.router.navigate(['/assignment']);
    }
    else if(response.responseStatus==5){
      //window.location.reload();
      Swal.fire('Invalid File. Please choose correct file format.',response.responseMsgCode,'error');
      //this.router.navigate(['/assignment']);
    }else if(response.responseStatus==7){
      //window.location.reload();
      Swal.fire('Record not available.',response.responseMsgCode,'error');
      //this.router.navigate(['/assignment']);
    }else{
      Swal.fire('Please choose file.',response.responseMsgCode,'error');
      //this.router.navigate(['/assignment']);
    }    
  }
  handleError(error:any) {
    this.assignmentForm=false;
    Swal.fire('Request failed !!!',"Something went wrong.",'error');
  }
  chnageStatus(id:any, status:any){
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to change status of this user',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, change it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.common.changeStatus({id:id, status:status}).subscribe(
          response => {            
            this.getMenuList();
            Swal.fire(
              'Success!',
              'User status has been changed.',
              'success'
            )
          },
          (error) => this.handleError(error)
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'User is safe :)',
          'error'
        )
      }
    })
  }
  myFunction() {
    var input:any, filter:any, table:any, tr:any, td:any, i:any, txtValue:any;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }  
  }

  deleteAllRecord(del:any){
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete records',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.common.deleteallRecord(del).subscribe(
          response => {            
            this.getMenuList();
            Swal.fire(
              'Record deleted successfully!',
              'Record deleted successfully!.',
              'success'
            )
            window.location.reload();
          },
          (error) => this.handleError(error)
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'User is safe :)',
          'error'
        )
       // window.location.reload();
      }
    })
  }
}
