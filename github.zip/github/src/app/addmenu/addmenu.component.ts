import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from 'src/app/global/services/common/common.service';
import { NgForm, FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-addmenu',
  templateUrl: './addmenu.component.html',
  styleUrls: ['./addmenu.component.css']
})
export class AddmenuComponent implements OnInit {
  baseURL = environment.imageBaseUrl;
  menuData: any = {
    menuname: '',
    image:''
  }
  @ViewChild('addMenuForm') form: FormGroup;
  
  title: string = 'Add Menu Page';
  submitForm: boolean = false;
  fileData1:File;
  fileData1Label: string;
  fileData1Error:boolean = false;

  constructor( private common: CommonService, private router: Router, private elementRef: ElementRef) { }

  ngOnInit() {
  }
  onFileSelect(event:any) {
    this.fileData1 = event.target.files[0];
    this.fileData1Label = this.fileData1.name;
    this.fileData1Error = false;
  }
  addMenuDetails() {    
    this.submitForm = true;
    let data = {
      menuname : this.menuData.menuname,
      image: this.fileData1
    }

   

    if (this.form.valid) {
      this.common.saveMenu(data).subscribe(     
        response => {
          this.handleResponse(response)
        },
        (error) => this.handleError(error)
      );
    } else {
     
    }
  }
  handleResponse(response:any) {   
    //console.log(response);   
   
    if(response.responseStatus=="1"){
      this.form.reset();
      this.submitForm = false;
      this.fileData1Label = "";
      this.fileData1Error = true;
      this.router.navigate(['/menulist']);
      Swal.fire('Successful!', response.responseMsgCode, 'success');
    }
    else if(response.responseStatus=="0"){
      this.form.reset();
      this.submitForm = false;
      this.fileData1Label = "";
      this.fileData1Error = true;
      this.router.navigate(['/addmenu']);
      Swal.fire('Menu name already exist!', response.responseMsgCode, 'error');
    }else{
      Swal.fire('Invalid Request!!', response.responseMsgCode, 'warning');
    }
  }
  handleError(error:any) {
    if(error.error.password){
      error.error.message=error.error.password;
      Swal.fire('Password must be at least 6 characters !!!', '', 'error');
    } else if(error.error.password2){
      error.error.message=error.error.password2;
      Swal.fire('Paaaword not match !!!', '', 'error');
    }else{     
      Swal.fire('Request failed !!!', error.error.message, 'error');
    }
    
  }
}

