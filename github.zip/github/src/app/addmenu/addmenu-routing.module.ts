import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddmenuComponent } from './addmenu.component';

const routes: Routes = [{ path: '', component: AddmenuComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddmenuRoutingModule { }
