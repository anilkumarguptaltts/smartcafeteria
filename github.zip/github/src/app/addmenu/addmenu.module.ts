import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddmenuRoutingModule } from './addmenu-routing.module';
import { AddmenuComponent } from './addmenu.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddmenuComponent],
  imports: [
    CommonModule,
    AddmenuRoutingModule,
    FormsModule
  ]
})
export class AddmenuModule { }
