import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AfterLoginGuardService } from 'src/app/global/services/guards/after-login-guard.service';

const routes: Routes = [
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) }, 
  { path: 'signup', loadChildren: () => import('./signup/signup.module').then(m => m.SignupModule) }, 
  { path: 'user-details', loadChildren: () => import('./user-details/user-details.module').then(m => m.UserDetailsModule),canActivate: [AfterLoginGuardService]},
  { path: 'assignment', loadChildren: () => import('./assignment/assignment.module').then(m => m.AssignmentModule),canActivate: [AfterLoginGuardService]  },
  { path: 'homepage', loadChildren: () => import('./homepage/homepage.module').then(m => m.HomepageModule) },
  { path: 'menulist', loadChildren: () => import('./menulist/menulist.module').then(m => m.MenulistModule),canActivate: [AfterLoginGuardService]  },
  { path: 'addmenu', loadChildren: () => import('./addmenu/addmenu.module').then(m => m.AddmenuModule),canActivate: [AfterLoginGuardService]  }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
