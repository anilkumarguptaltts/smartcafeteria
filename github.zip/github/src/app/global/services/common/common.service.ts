
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private apiBaseUrl = environment.apiBaseUrl;
  
  constructor(private router: Router, private http: HttpClient) { }

  
  saveSignup(data:any): Observable<any> {
    //console.log(data)
    const _formData = new FormData();
    _formData.append('firstname', data.firstname);
    _formData.append('lastname', data.lastname);
    _formData.append('email', data.email);
    _formData.append('password', data.password);
    _formData.append('password2', data.password2);
    _formData.append('image', data.image);
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/saveSignup', _formData);
  }
  saveMenu(data:any): Observable<any> {
    console.log(data)
    const _formData = new FormData();
    _formData.append('menuname', data.menuname);
    _formData.append('image', data.image);
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/saveMenu', _formData);
  }
  getsearchMenuWeekWise(data:any): Observable<any> {
   return this.http.post(this.apiBaseUrl + 'admin/signupUser/getsearchMenuWeekWise', data);
 }
  getUserDetail(data:any): Observable<any> {
    return this.http.post(this.apiBaseUrl + 'admin/users/getuserdetail', data);
  }

  updateProfile(data:any): Observable<any> {
    const _formData = new FormData();
    _formData.append('firstname', data.firstname);
    _formData.append('lastname', data.lastname);
    _formData.append('email', data.email);
    _formData.append('_id', data._id);
    _formData.append('image', data.image);   
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/updateprofile', _formData);
  }
  uploadExcel(data:any): Observable<any> {
    const _formData = new FormData();    
    _formData.append('image', data.image);   
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/uploadExcel', _formData);
  }
  getUserListing(): Observable<any> {
    return this.http.get(this.apiBaseUrl + 'admin/signupUser/getUserListing');
  }
  getMenuListing(): Observable<any> {
    return this.http.get(this.apiBaseUrl + 'admin/signupUser/getMenuListing');
  }
  getMenuWeekWise(): Observable<any> {
    return this.http.get(this.apiBaseUrl + 'admin/signupUser/getMenuWeekWise');
  }
  changeStatus(data:any): Observable<any> {
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/changeStatus', data);
  }
  deleteallRecord(data:any): Observable<any> {
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/deleteAllRecord',data);
  }
  getdishList(): Observable<any> {
    return this.http.get(this.apiBaseUrl + 'admin/signupUser/getdishList');
  }
  deleteMenu(data:any): Observable<any> {
    return this.http.post(this.apiBaseUrl + 'admin/signupUser/deleteMenu', data);
  }
}
