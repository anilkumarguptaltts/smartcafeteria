import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MenulistRoutingModule } from './menulist-routing.module';
import { MenulistComponent } from './menulist.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [MenulistComponent],
  imports: [
    CommonModule,
    MenulistRoutingModule,
    FormsModule
  ]
})
export class MenulistModule { }
