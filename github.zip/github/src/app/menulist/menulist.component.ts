import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from 'src/app/global/services/common/common.service';
import Swal from 'sweetalert2';
import { AuthService } from 'src/app/global/services/authentication/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgForm, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-menulist',
  templateUrl: './menulist.component.html',
  styleUrls: ['./menulist.component.css']
})
export class MenulistComponent implements OnInit {
  baseURL = environment.imageBaseUrl;

  @ViewChild('dishForm') form: FormGroup;
  dishList : any;

  constructor(private auth: AuthService, private common: CommonService, private router: Router) { }

  ngOnInit(): void {
    this.getdishList();
  }
  getdishList(){
    this.common.getdishList().subscribe( response => {
        this.dishList = response.responseData;
      },
      (error:any) => this.handleError(error)
    );
  }
  handleError(error:any) {
    if(error.error.password){
      error.error.message=error.error.password;
      Swal.fire('Password must be at least 6 characters !!!', '', 'error');
    } else if(error.error.password2){
      error.error.message=error.error.password2;
      Swal.fire('Paaaword not match !!!', '', 'error');
    }else{     
      Swal.fire('Request failed !!!', error.error.message, 'error');
    }    
  }
  myFunction() {
    var input:any, filter:any, table:any, tr:any, td:any, i:any, txtValue:any;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }  
  }

  deleteMenu(id:any){
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete menu',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, change it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.common.deleteMenu({id:id}).subscribe(
          response => {            
            this.getdishList();
            Swal.fire(
              'Success!',
              'Menu delete susccessfully.',
              'success'
            )
          },
          (error) => this.handleError(error)
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'User is safe :)',
          'error'
        )
      }
    })
  }
  gotoProfile3() {   
    this.router.navigate(['/addmenu']);
  }
}
