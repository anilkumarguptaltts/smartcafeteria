import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/global/services/common/common.service';
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  baseURL = environment.imageBaseUrl;
  signupData: any = {
    fromdate: '',
    todate:'',
    menuname:''
  }
  @ViewChild('homeForm') form: FormGroup;
  title: string = 'Home Page';
  homepageForm: boolean = false;
  getMenuWeekWiseData:any;  
  fromdate:any;
  isLoading: boolean = false;
  
  constructor(
    private router: Router,
    private common:CommonService,
    private formBuilder: FormBuilder,
    ) { }


  ngOnInit() {
    this.getMenuWeekWise();
  }
  
  get f() { return this.form.controls; }

  searchMenuDateWise() {
    this.isLoading = true;
    let data = {
      fromdate : this.signupData.fromdate,
      todate : this.signupData.todate,
      menuname : this.signupData.menuname,      
    }
    this.common.getsearchMenuWeekWise(data).subscribe( response => { 
      this.isLoading = false;  
      console.log('----clickload-----1');
      console.log(response);
      console.log('----clickload-----2');
     
      this.getMenuWeekWiseData = response.responseData;
    },
      (error:any) => this.handleError(error)
    );

  }
  getMenuWeekWise(){
    
    console.log('----autoload-----');
    this.common.getMenuWeekWise().subscribe( response => {       
      this.getMenuWeekWiseData = response.responseData;     
      },
      (error:any) => this.handleError(error)
    );
  }
  handleResponse(response:any) {   
    this.homepageForm=false;
    if(response.responseStatus){
     // window.location.reload();
      Swal.fire('Successful!',response.responseMsgCode,'success');
      this.router.navigate(['/my-profile']);
    }else{
      Swal.fire('Uploaded Successful!',response.responseMsgCode,'success');
      this.router.navigate(['/assignment']);
    }    
  }
  handleError(error:any) {
    this.homepageForm=false;
    Swal.fire('Request failed !!!',"Something went wrong.",'error');
  }
  resetFilter(){
    window.location.reload();
  }
}
