require('rootpath')();
const Express = require("express");
const bodyParser = require("body-parser");
const path = require('path');
const http = require('http');
const app = Express();



app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 1000000 }));
app.use(bodyParser.json());
var cors = require('cors');
app.use(cors({ origin: 'http://localhost:4200' }));
app.use(Express.static(path.join(__dirname, 'public')));
app.use('/admin', require('./adminApi/api'));


process.env['TZ'] = 'UTC';
const port = process.env.PORT || '8081';
app.set('port', port);

const server = http.createServer(app);

server.listen(port, () => console.log(`Running on server:${port}`));