const Validator = require("validator");
const isEmpty = require("is-empty");
module.exports = function validateMenuInput(data) {
    let errors = {};
    data.menuname = !isEmpty(data.menuname) ? data.menuname : "";
   
    if (Validator.isEmpty(data.menuname)) {
        errors.menuname = "Menu name field is required";
    }
    return {
        errors,
        isValid: isEmpty(errors)
    };
};