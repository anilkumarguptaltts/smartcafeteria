const express = require('express');
const router = express.Router();
const validateLoginInput = require('../validation/login');
var adminModel = require('adminApi/model/admin.model');

 router.post('/login', login);
 router.post('/getuserdetail', getuserdetail);

 module.exports = router;


function login(req, res) {
	const { errors, isValid } = validateLoginInput(req.body);
	if (!isValid) {
		res.status(400).json(errors);
	}
	adminModel.authenticate(req.body)
		.then(function (user) {
			//console.log(user)
			if (user == "userFail") {
				res.status(400).send({ status: false, message: "User name not found" });
			} else if (user == "passFail") {
				res.status(400).send({ status: false, message: "Entered password is incorrect" });
			}else if (user == "emailFail") {
				res.status(400).send({ status: false, message: "Entered email is incorrect" });
			}else {				
				res.status(200).send({ status: true, token: user.token, message: "You have been logged in successfully." });
			}
		}).catch(function (err) {
			res.status(400).send({ status: false, message: "Please enter a valid emailid & password." });
		});

}
function getuserdetail(req, res) {
	adminModel.getaccount(req.body)
		.then(function (user) {
			res.status(200).send({ status: true, userdata: user });
		}).catch(function (err) {
			res.status(400).send({ status: false, message: "error in updation" });
		});

}