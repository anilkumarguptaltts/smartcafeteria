const express = require('express');
const router = express.Router();
const path = require('path');
var multer = require('multer');
var userModel = require('adminApi/model/user.model');
const validateRegisterInput = require('../validation/register');
const validateMenuInput = require('../validation/menu');

 //foodimage Storage
var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, path.join(`${__dirname}/../../public/foodimage`))		
	},
	filename: function (req, file, cb) {
		let filename = file.originalname.replace(" ", "-");
		cb(null, Date.now() + '-' + filename)
	}
});
var upload = multer({ storage: storage });

 //Profile Storage
var storage1 = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, path.join(`${__dirname}/../../public/user`))		
	},
	filename: function (req, file, cb) {
		let filename = file.originalname.replace(" ", "-");
		cb(null, Date.now() + '-' + filename)
	}
});
var upload1 = multer({ storage: storage1 });


router.post('/saveSignup', upload1.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), saveSignup);
router.post('/saveMenu', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), saveMenu);
router.post('/updateprofile', upload1.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), updateProfile);
router.post('/uploadExcel', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), uploadExcel);
router.get('/getUserListing',getUserListing);
router.get('/getMenuListing',getMenuListing);
router.post('/changeStatus',changeStatus);
router.get('/getMenuWeekWise',getMenuWeekWise);
router.post('/getsearchMenuWeekWise',getsearchMenuWeekWise);
router.post('/deleteAllRecord',deleteAllRecord);
router.get('/getdishList',getDishList);
router.post('/deleteMenu',deleteMenu);

module.exports = router;

function saveMenu(req, res) {
	//console.log("=======>");	
   // console.log(req.body);
	//return false;
	const { errors, isValid } = validateMenuInput(req.body);
	if (!isValid) {
		res.status(400).json(errors);
	}else{

		if(req.files){
			req.body.image = req.files.image[0].filename
		}else{
			req.body.image=''; 
		}		
		if(req.body.image==""){
			return res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Image is mandatory to upload.", "responseInvalid": 0 });
		}		
	userModel.saveMenu(req.body).then(function (signupdata) {
		data = {}
		if (signupdata.status==true) {
			res.status(200).send({ "responseStatus": 1, "responseMsgCode": signupdata.message, "responseData": data, "responseInvalid": 0 });
		} else {
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": signupdata.message, "responseInvalid": 0 });
		}
	}).catch(function (err) {
		// console.log('13/11/2021')
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
	})

	}
}
function saveSignup(req, res) {
	    //console.log("=======>");	
	   // console.log(req.body);
		//return false;
		const { errors, isValid } = validateRegisterInput(req.body);
		if (!isValid) {
			res.status(400).json(errors);
		}else{

			if(req.files){
				req.body.image = req.files.image[0].filename
			}else{
				req.body.image=''; 
			}		
			if(req.body.image==""){
				return res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Image is mandatory to upload.", "responseInvalid": 0 });
			}		
		userModel.savesignup(req.body).then(function (signupdata) {
			data = {}
			if (signupdata) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": signupdata.message, "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": signupdata.message, "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log('13/11/2021')
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
		})

		}
	
}
function updateProfile(req, res) {	
	try {
		if(req.files.image && req.files.image!=undefined){
			req.body.image = req.files.image[0].filename;
		}else{
			delete req.body.image; 
		}	
		userModel.updateProfile(req.body).then(function (profiles) {
			data = {}
			if (profiles) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": profiles.message, "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong while updating details.", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function uploadExcel(req, res) {
	
	try {
		if(req.files.image && req.files.image!=undefined){
			req.body.image = req.files.image[0].filename;
		}else{
			delete req.body.image; 
		}	
		userModel.uploadExcel(req.body).then(function (uploadexceldata) {
			
			//console.log('------------201');
			//console.log(uploadexceldata);
			//console.log('------------301');
			//return false;
			
			if (uploadexceldata.docresult==1) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "Uploaded Successfully!", "responseInvalid": 0 });
			} 
			else if (uploadexceldata=='norecord') {
				res.status(200).send({ "responseStatus": 7, "responseMsgCode": "Record not availabel!", "responseInvalid": 0 });
			}else {
				res.status(200).send({ "responseStatus": 2, "responseMsgCode": "Data added and updated successfully!", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			console.log('------------5001');
			console.log(err);
			console.log('------------6001');
			if(err.errno=='-4058')
			{
				res.status(200).send({ "responseStatus": 3, "responseMsgCode": "File not available.", "responseInvalid": 0 });
			}
			else if(err.errno=='blank')
			{
				res.status(200).send({ "responseStatus": 4, "responseMsgCode": "Some Data already exist OR Some New Data insert successfully", "responseInvalid": 0 });
			}else{
				res.status(200).send({ "responseStatus": 5, "responseMsgCode": "Invalid File.", "responseInvalid": 0 });
			}

			
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 40, "responseMsgCode": "Something went wrong while updating details.", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function getUserListing(req, res) {

	try {
		userModel.getUserListing(req.body).then(function (Userdata) {
			data = {}
			if (Userdata) {
				data = Userdata;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "userDataFetched", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "noDataAvailable", "responseInvalid": 0 });
			}
		}).catch(function (err) {
				// console.log(err);
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
			})


	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function getMenuListing(req, res) {

	try {
		userModel.getMenuListing(req.body).then(function (Userdata) {
			data = {}
			if (Userdata) {
				var week = new Array(        
					"Monday",
					"Tuesday",
					"Wednesday",
					"Thursday",
					"Friday",
					"Saturday",
					"Sunday"
				  );
				data = Userdata;
				//var combindData = {"Weekday": week,"getData": data};
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "userDataFetched", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "noDataAvailable", "responseInvalid": 0 });
			}
		}).catch(function (err) {
				// console.log(err);
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
			})


	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function getMenuWeekWise(req, res) {
	
	try {
		userModel.getMenuWeekWise(req.body).then(function (Userdata) {
			// console.log('Userdata1');
			// console.log(Userdata);
			// console.log('Userdata2');
			// return false;

			if (Userdata) {				
				res.status(200).send({ "responseStatus": 1,
				"responseData": Userdata, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "noDataAvailable", "responseInvalid": 0 });
			}
		}).catch(function (err) {
				// console.log(err);
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
			})


	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function changeStatus(req, res) {

	try {
		userModel.getChangeStatus(req.body).then(function (userstatus) {
			data = {}
			if (userstatus) {
				data = userstatus;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "User status changed successfully.", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function getsearchMenuWeekWise(req, res) {	
	try {
		userModel.getsearchMenuWeekWise(req.body).then(function (profiles) {

			//console.log(profiles);
			//return false;

			if (profiles.length>0) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": profiles.message, "responseData": profiles, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong while updating details.", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function deleteAllRecord(req, res) {
	try {
		userModel.deleteAllRecord(req.body).then(function (userstatus) {
			data = {}
			if (userstatus) {
				data = userstatus;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "User status changed successfully.", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function getDishList(req, res) {

	try {
		userModel.getdishList(req.body).then(function (Userdata) {
			data = {}
			if (Userdata) {
				data = Userdata;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "userDataFetched", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "noDataAvailable", "responseInvalid": 0 });
			}
		}).catch(function (err) {
				// console.log(err);
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
			})


	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
function deleteMenu(req, res) {

	try {
		userModel.getdeleteMenu(req.body).then(function (userstatus) {
			data = {}
			if (userstatus) {
				data = userstatus;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "User status changed successfully.", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
