﻿var config = require('config.json');
var bcrypt = require('bcryptjs');
const crypto = require("crypto");
const path = require('path');
const moment = require('moment');
var Q = require('q');
const excelToJson = require('convert-excel-to-json');
const { isConstructSignatureDeclaration } = require('typescript');
const { async } = require('rxjs');
var ObjectId = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;
var db;
MongoClient.connect(config.connection, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, dbo) {
	if (err) throw err;
	db = dbo.db(config.dbname);
	// dbo.close();
});


var service = {};

//User Profiles
service.savesignup = saveSignup;
service.updateProfile=updateProfile;
service.getUserListing=getUserListing;
service.getMenuListing=getMenuListing;
service.getChangeStatus=getChangeStatus;
service.uploadExcel=uploadExcel;
service.getMenuNameById=getMenuNameById;
service.getMenuWeekWise=getMenuWeekWise;
service.getsearchMenuWeekWise=getsearchMenuWeekWise;
service.deleteAllRecord=deleteAllRecord;
service.getdishList=getdishList;
service.getdeleteMenu=getdeleteMenu;
service.saveMenu=saveMenu;

module.exports = service;

function saveMenu(getParams){
	var deferred = Q.defer();
	//console.log('----model---------------');
	//console.log(getParams); return false;
	
	var _data = {
		"menuName":getParams.menuname,
		"status":1,				 
		"image":getParams.image,
		"created_date": new Date()
	}

	db.collection("tbl_menu").findOne({ menuName: getParams.menuname }, function (err, data) {
		if (data != null) {					
			deferred.resolve({ status: false, message: 'Menu name can not be duplicate. Please change it.' });
		}else{
			db.collection("tbl_menu").insertOne(_data, function(err, doc) {
				if (err)
					deferred.reject(err.name + ': ' + err.message);
				if(doc){
					deferred.resolve({ status: true, success: true, message: 'Menu added successfully' });
				}else{
					deferred.resolve();
				}
				
			});
		} 
	})
	
	return deferred.promise;

}
function saveSignup(getParams){
	var deferred = Q.defer();
	//console.log('----model---------------');
	//console.log(getParams); return false;
	
	var _data = {
		"firstname":getParams.firstname,				 
		"image":getParams.image,
		"lastname":getParams.lastname,
		"status":1,
		"email":getParams.email,
		"password":bcrypt.hashSync(getParams.password, 10),
		"add_on": new Date()
	}

	db.collection("tbl_users").findOne({ email: getParams.email }, function (err, data) {
		if (data != null) {					
			deferred.resolve({ status: false, message: 'Email can not be duplicate. Please change it.' });
		}else{
			db.collection("tbl_users").insertOne(_data, function(err, doc) {
				if (err)
					deferred.reject(err.name + ': ' + err.message);
				if(doc){
					deferred.resolve({ success: true, message: 'User added successfully' });
				}else{
					deferred.resolve();
				}
				
			});
		} 
	})
	
	return deferred.promise;

}
async function uploadExcel(getParams){
var deferred = Q.defer();
const result = excelToJson({
    sourceFile: path.join(`${__dirname}/../../public/foodimage/`+getParams.image),
	header:{
        // Is the number of rows that will be skipped and will not be present at our result object. Counting from top to bottom
        rows: 1 // 2, 3, 4, etc.
    },
	columnToKey: {
        A: 'A1',
        B: 'B1',
		C: 'C1',
		D: 'D1',
		E: 'E1',
		F: 'F1'
	}
});
/*var Jsondata = [
	{
		'Month1':
		{
			'Week1':result.Month1Week1,
			'Week2':result.Month1Week2,
			'Week3':result.Month1Week3,
			'Week4':result.Month1Week4
		},
		'Month2':
		{
			'Week1':result.Month2Week1,
			'Week2':result.Month2Week2,
			'Week3':result.Month2Week3,
			'Week4':result.Month2Week4
		}
	}
]*/
//delete result.Sheet1[0];

	//console.log('------>>>>>>');
	//console.log(result.Week1.length);
	//return false;

if(result.Week1.length>0)
{
		for (const type of result.Week1) {
			//console.log('------>>>>>>');
			//console.log(type.E1);
			//return false;
			//console.log('------<<<<<>>>>>>>>>>>');
			
			//return false;
			var array1 = type.E1.split(',');
			//console.log(array1.length);
			//return false;
			// if(array1.length==1){
			// 	array1.length=1;
			// }
			var AllData =[];
			var SkipData =[];
			for(i=0;i<=array1.length;i++)
			{
				var d = new Date();
				//var current_month_date = moment(new Date()).format("YYYY-MM-DD")
				var threemonthdate = d.setMonth(d.getMonth() + 3);
				var three_month_date = moment(new Date(threemonthdate)).format("YYYY-MM-DD")

				const currtdate = new Date(array1[i]);
				const threemdate = new Date(three_month_date);		
				//console.log(currtdate +"--------"+currtdate.getTime()+'======'+threemdate.getTime());
				//return false;

				if(currtdate.getTime() <= threemdate.getTime())
				{
					//console.log('-----------case1-----');
					var getMenuId = await getMenuName(type.A1);

					if(getMenuId)
					{
						//console.log('-----------case2-----');
						var getExistId = await checkMenuExist(getMenuId,array1[i]);
						//console.log('-----------akg-----'+menuIdAndDate);
						if(getExistId)
						{
						//update
						var getupdateId = await updateMenu(getExistId,getMenuId,array1[i]);
						//console.log('-----------existId-----'+getupdateId);
						}
						else
						{
							var Jsondata =
								{
									"menu_id" : getMenuId,
									"price" : type.B1,
									"status" : type.C1,
									"description" : type.D1,
									"displaydate" : array1[i],				
									"createddate": new Date(),

								}
								if(array1[i] ===undefined){
									continue;
								}else{
									AllData.push(Jsondata);
								}

							}
					}
					
				}
				else
				{
					if(array1[i] ===undefined){
						continue;
					}else{
						SkipData.push(array1[i]);
					}
					
				}
			}
			if(AllData.length>0)
			{
			db.collection("tbl_items").insertMany(AllData, function(err, doc) {
				if (err) deferred.reject(err.name + ': ' + err.message);
				//data ={};
				if (doc) {
					//data = SkipData;
					
					//console.log('--------part100');
					//console.log(SkipData);
					//console.log('--------part101');

					deferred.resolve({'docresult':doc.result.ok,'getupdateId':getupdateId});
				} else {
					deferred.resolve();
				}
			});
		   }else{
			deferred.resolve('blank');
		   }
		}
	}
	else
	{
		deferred.resolve('norecord');
	}
	return deferred.promise;
}
function updateMenu(getExistId,getMenuId,displaydate) {
	//console.log("=========>" +Id)
	var deferred = Q.defer();
	db.collection('tbl_items').updateOne({ _id: ObjectId(getExistId) }, { $set: {'menu_id':getMenuId,'displaydate':displaydate} }, function (err, data) {
			
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (data) {
			deferred.resolve({"getMenuId":getMenuId,'displaydate':displaydate});
		} else {
			deferred.resolve();
		}
	});

	return deferred.promise;
}
function checkMenuExist(menuId,displaydate) {
	//console.log("=========>" +Id)
	var deferred = Q.defer();
	db.collection("tbl_items").findOne({ menu_id: menuId,displaydate: displaydate },{ projection: { menu_id:1}}, function (err, user) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (user) {
			deferred.resolve(user._id);

		} else {
			deferred.resolve(0);
		}
	});

	return deferred.promise;
}
function getMenuName(menuname) {
	var deferred = Q.defer();
	db.collection("tbl_menu").findOne(
		{ menuName: menuname },
		{ projection: { menu_name: 1}}, function (err, user) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (user) {
			deferred.resolve(user._id);

		} else {
			deferred.resolve("error");
		}
	});

	return deferred.promise;
}
function getMenuNameById(Id) {
	//console.log("=========>" +Id)
	var deferred = Q.defer();
	db.collection("tbl_menu").findOne({ _id: Id },{ projection: { menuName: 1,image:1}}, function (err, user) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (user) {
			//console.log(user);
			deferred.resolve(user);

		} else {
			deferred.resolve("error");
		}
	});

	return deferred.promise;
}
function updateProfile(getParams){
	
	var deferred = Q.defer();
	
	// console.log('========================');
	// console.log(getParams); return false;
	if(typeof getParams.image ===undefined){
		var data = {
			"firstname":getParams.firstname,				 
			"lastname":getParams.lastname,
			"email":getParams.email,			
			"update_on": new Date()
		}
	}else{
		var data = {
			"firstname":getParams.firstname,				 
			"image":getParams.image,
			"lastname":getParams.lastname,
			"email":getParams.email,			
			"update_on": new Date()
		}
	}
	if(getParams._id){
	
		db.collection('tbl_users').updateOne({ _id: ObjectId(getParams._id) }, { $set: data }, function (err, data) {
			
			if (err) deferred.reject(err.name + ': ' + err.message);
			if (data) {
				deferred.resolve({ status: true, message: 'Profile updated successfully' });
			} else {
				deferred.resolve();
			}
		});
		
	}else{
		deferred.resolve();
	}
	return deferred.promise;


}
function getMenuListing(){
	var deferred = Q.defer();
	db.collection("tbl_items").find({}).sort( { "displaydate": 1 } ).toArray(async  function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {
			let elmentArr =[];
			await data.map(async element=>{
				var menuNameById = await getMenuNameById(element.menu_id);
				element.menu_name = menuNameById.menuName;
				element.image = menuNameById.image;			
				elmentArr.push(element);
				if(elmentArr.length == data.length){
					deferred.resolve(elmentArr);
				}				
			})

		} else {
			deferred.resolve('');
		}

	});
	return deferred.promise;	
}
function getdishList(){
	var deferred = Q.defer();
	db.collection("tbl_menu").find({}).sort( { "created_date": 1 } ).toArray(async  function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {
			deferred.resolve(data);
		} else {
			deferred.resolve('');
		}
	});
	return deferred.promise;	
}
async function getsearchMenuWeekWise(getParams)
{  
	var deferred = Q.defer();
	
	//console.log('clickload---');
	//console.log(getParams);
	
	//console.log('clickload---'+getMenuId);
	var getMenuId = await getMenuName(getParams.menuname);
	if(getParams.fromdate !='' && getParams.todate !='' && getParams.menuname !='')
	{		
		//console.log('three---');
		var fromDate = moment(new Date(getParams.fromdate)).format("YYYY-MM-DD");
		var toDate = moment(new Date(getParams.todate)).format("YYYY-MM-DD");

		var match = {"menuList.displaydate": { $gte: fromDate, $lte: toDate },"menuList.status": 1,"menuList.menu_id": getMenuId}
	}
	else if(getParams.fromdate !='' && getParams.todate !='')
	{//console.log('two---');
		var fromDate = moment(new Date(getParams.fromdate)).format("YYYY-MM-DD");
		var toDate = moment(new Date(getParams.todate)).format("YYYY-MM-DD");
		var match = {"menuList.displaydate": { $gte: fromDate, $lte: toDate },"menuList.status": 1}
	}
	else
	{//console.log('one---');
		var match = {"menuList.status": 1,"menuList.menu_id": getMenuId}
	}
	//console.log('--------->>>start');
	//console.log(match);
	//console.log('--------->>>end');

	db.collection("tbl_menu").aggregate([
		{
		   $lookup:
			  {
				 from: "tbl_items",
				 localField: "_id",
				 foreignField: "menu_id",
				 as: "menuList"
			 }
		},
		{
		 $unwind: "$menuList",
		 },
		 { $sort : {"menuList.displaydate":1}},
		 { $match: match},
		{ 
			  $project : 
			  {
					  _id:1,
					  menuName:1,
					  menu_name:'$menuName.menu_id',
					  price:"$menuList.price",
					  status:"$menuList.status",
					  image:1,
					  description:"$menuList.description",
					  displaydate:"$menuList.displaydate",
					  createddate:"$menuList.createddate",
			  }
		}
	 ]).toArray(function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {
			deferred.resolve(data);
		} else {
			deferred.resolve('');
		}

	});
	return deferred.promise;
}
function getMenuWeekWise()
{
	var d = new Date();
	var current_month_date = moment(new Date()).format("YYYY-MM-DD")
	var threemonthdate = d.setMonth(d.getMonth() + 3);
	var three_month_date = moment(new Date(threemonthdate)).format("YYYY-MM-DD")
	const currtdate = new Date(current_month_date);
	const threemdate = new Date(three_month_date);
	//console.log(currtdate.getTime()+'======'+threemdate.getTime());
	//if(currtdate.getTime() <= threemdate.getTime()){
		//date 1 is newer
	//}


	var deferred = Q.defer();
	var fd   =new Date();
	var td   =new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
	var fdate = moment(new Date(fd)).format("YYYY-MM-DD")
	var tdate = moment(new Date(td)).format("YYYY-MM-DD")

	db.collection("tbl_menu").aggregate([
		{
		   $lookup:
			  {
				 from: "tbl_items",
				 localField: "_id",
				 foreignField: "menu_id",
				 as: "menuList"
			 }
		},
		{
		 $unwind: "$menuList",
		 },
		 { $sort : {"menuList.displaydate":1}},
		 { $match: {"menuList.displaydate": { $gte: fdate, $lte: tdate },"menuList.status": 1}},
		{ 
			  $project : 
			  {
					  _id:1,
					  menuName:1,
					  menu_name:'$menuName.menu_id',
					  price:"$menuList.price",
					  status:"$menuList.status",
					  image:1,
					  description:"$menuList.description",
					  displaydate:"$menuList.displaydate",
					  createddate:"$menuList.createddate",
			  }
		}
	 ]).toArray(function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {
			deferred.resolve(data);
		} else {
			deferred.resolve('');
		}

	});
	return deferred.promise;
}
function getUserListing(){
	var deferred = Q.defer();
	db.collection("tbl_users").find({}).sort( { "_id": -1 } ).toArray(function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {			
			deferred.resolve(data);
		} else {
			deferred.resolve('');
		}

	});
	return deferred.promise;
}
function getChangeStatus(getParams) {
	var deferred = Q.defer();
	var id = ObjectId(getParams.id);
	let status = (getParams.status==1)?0:1;

	db.collection("tbl_items").updateOne({ _id: id },{$set:{status:status}}, function (err, data) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (data) {
			deferred.resolve(data);
		} else {
			deferred.resolve();
		}
	});
	
	return deferred.promise;
}
function getdeleteMenu(getParams) {
	var deferred = Q.defer();
	var id = ObjectId(getParams.id);

	db.collection("tbl_menu").deleteOne({ _id: id },function (err, data) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (data) {
			deferred.resolve(data);
		} else {
			deferred.resolve();
		}
	});
	
	return deferred.promise;
}
function deleteAllRecord() {
	var deferred = Q.defer();
	db.collection("tbl_items").deleteMany({} , (err , data) => {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (data) {
			deferred.resolve(data);
		} else {
			deferred.resolve();
		}
	});	
	return deferred.promise;
}