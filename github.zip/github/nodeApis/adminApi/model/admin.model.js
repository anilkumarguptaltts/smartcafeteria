var bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
var Q = require('q');
ObjectId = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;
var config = require('config.json');
var db;
MongoClient.connect(config.connection, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, dbo) {
	if (err) throw err;
	db = dbo.db(config.dbname);
	// dbo.close();
});


var service = {};
service.authenticate = authenticate;
service.getaccount = getaccount;

module.exports = service;


function authenticate(reqBody) {
	var deferred = Q.defer();
	var email = reqBody.email;
	var password = reqBody.password;
	const currentTime = Date.now();	
	var d = new Date(currentTime);
		
	db.collection("tbl_users").findOne({ email: email }, function (err, user) {

	if (err) deferred.reject(err.name + ': ' + err.message);
		if (user) {

			if (user && bcrypt.compareSync(password, user.password)) {
						
						const payload = {
							data: {
								_id: user._id,
								firstname: user.firstname,
								email: user.email,
								password: user.password,
								lastname: user.lastname,
								image: user.image,
							}
						};
						jwt.sign(
							payload,
							config.secretOrKey,
							{								
								 expiresIn: 31556926
							},
							(err, token) => {								
								
								deferred.resolve({ token });
							}
						);
			} else {
				deferred.resolve("passFail");
			}

		} else {
			deferred.resolve("emailFail");
		}
	});

	return deferred.promise;
}
function getaccount(userParam) {
	var deferred = Q.defer();
	db.collection("tbl_users").findOne({ _id: ObjectId(userParam.id) },{ projection: { firstname: 1,email: 1,lastname: 1,password:1,image:1 }}, function (err, user) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (user) {
			deferred.resolve(user);

		} else {
			deferred.resolve("error");
		}
	});

	return deferred.promise;
}












